Welcome to Wumpus World! Your goal as the robot is to find the gold hidden 
somewhere in the world without falling in a pit or becoming a tasty dinner 
for the dreaded Wumpus. If you find the gold, you win!

INSTRUCTIONS:
Use w to move up
Use a to move left
Use s to move down
Use d to move right

If you move to a cell adjacent to a pit, you feel a breeze.
If you move to a cell adjacent to the Wumpus, you detect a stench.
If you move to a cell adjacent to the gold, you see a glitter.

Good luck and happy hunting!