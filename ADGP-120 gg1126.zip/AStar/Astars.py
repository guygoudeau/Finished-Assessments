import pygame as gfx # imports pygame module

# predefined rgb values
black = (0, 0, 0)
white = (255, 255, 255) 
blue = (0, 0, 255)
green = (0, 255, 0)
red = (255, 0, 0)
purple = (160, 32, 240)

class Node(object):
	def __init__(self, x, y, reachable): # initalize node with all of its attributes
		self.reachable = reachable # is cell a wall?
		self.x = x # x variable
		self.y = y # y variable
		self.g = 0 # G score
		self.h = 0 # H score (Heuristic)
		self.f = 0 # F score (G+H)
		self.parent = None # parent set to None
		self.color = white # default color is white
		self.width = 37 # width of square drawn on screen
		self.height = 37 # height of square drawn on screen
		self.margin = 5 # margin between squares
		self.left = (self.margin + self.width) *  x + self.margin # left corner of square
		self.top = (self.margin + self.height) *  y + self.margin # top corner of square
		self.center = (self.left + (self.width/2)), (self.top + (self.height/2)) # center of square
		self.pos = (x, self.height - y) # x and y position
		self.IsStart = False # not start by default
		self.IsGoal = False # not goal by default
		
	def draw(self, screen, color): # draws the path line and colors the node squares
		margin = self.margin
		color = white if (self.reachable) else red # walls are red, not-walls are white
		if (self.IsStart == True): # if something is marked as start, its blue
			color = blue
		if (self.IsGoal == True): # if something is marked as goal, its green
			color = green
		gfx.draw.rect(screen, color, (self.left , self.top, self.width, self.height)) # draw line from middle of square

class AStar(object):
	def __init__(self, SearchSpace, Start, Goal): # Initialize A* with all its attributes
		self.open = [] # open list
		self.close = [] # closed list
		self.nodes = SearchSpace # nodes list
		self.grid_height = 6 # columns
		self.grid_width = 6 # rows
		self.start = Start # set start to Start
		self.goal = Goal # set goal to Goal
		self.current = self.start # set current to start
		
	def manhatten(self, node): # Heuristic value H: distance between this node and goal multiplied by 10
		return 10 * (abs(node.x - self.goal.x) + abs(node.y - self.goal.y)) # <- manhatten distance
		
	def diagonal(self, node): # Finds a diagonal Heuristic value
		xDistance = abs(node.x - self.goal.x) # absolute distance of x from goal
		yDistance = abs(node.x - self.goal.x) # absolute distance of y from goal
		if (xDistance > yDistance): # formula
			return 14*yDistance + 10*(xDistance-yDistance)
		else:
			return 14*xDistance + 10*(yDistance-xDistance)
		
	def get_node(self, x, y): # return a node based on x and y coords
		return self.nodes[x * self.grid_height + y]
		
	def get_adjacent_nodes(self, node): # retrieve list of adjacent nodes to a specific node
		nodes = [] # list of nodes to store once direction of adj nodes are found
		if node.reachable == True:
			if node.x < self.grid_width-1:
				nodes.append(self.get_node(node.x+1, node.y)) # x down
			if node.y > 0:
				nodes.append(self.get_node(node.x, node.y-1)) # y left
			if node.x > 0:
				nodes.append(self.get_node(node.x-1, node.y)) # x up
			if node.y < self.grid_height-1:
				nodes.append(self.get_node(node.x, node.y+1)) # y right
				
			if node.x < self.grid_width-1 and node.y > 0:
				nodes.append(self.get_node(node.x-1,node.y+1)) # up and right
			if node.x < self.grid_width-1 and node.y < self.grid_height-1:
				nodes.append(self.get_node(node.x+1,node.y+1)) # down and right
			if node.x > 0 and node.y > 0:
				nodes.append(self.get_node(node.x-1,node.y-1)) # up and left
			if node.x < self.grid_width-1 and node.y < self.grid_height-1:
				nodes.append(self.get_node(node.x+1,node.y-1)) # down and left
			return nodes
		
	def print_path(self): # print a path to console
		node = self.goal # this node is the goal
		while node.parent is not self.start: # while the goal's parent doesn't yet go back to start
			node = node.parent # go to next parent and
			print 'path: node: %d,%d' % (node.x, node.y) # print x and y of path 
			
	def draw_path(self, screen): # draws the line of the path to screen
		n = self.goal # this node is the goal
		while n.parent != None: # while goal's parent does not equal None
			gfx.draw.line(screen, purple, n.center, n.parent.center, 5) # draw a purple line from center of node
			n = n.parent # go to next parent
			
	def update_node(self, adj, node): # Calculate G, H and F score and set parent node
		if adj.reachable == True: # if the adjacent node is reachable (not a wall), calculate F, G and H scores
			adj.g = self.calc_g(node, adj)
			adj.h = self.diagonal(adj)
			adj.f = adj.h + adj.g
			adj.parent = node # make current node parent of this node
		
	def calc_g(self, node1, node2): # function to calculate G score
		if (abs(self.nodes.index(node1) - self.nodes.index(node2)) == 6) or (abs(self.nodes.index(node1) - self.nodes.index(node2)) == 1): # 6 or 1 is cost for left right up down
			return 10 # for horizontal/lateral movement
		if (abs(self.nodes.index(node1) - self.nodes.index(node2)) == 7) or (abs(self.nodes.index(node1) - self.nodes.index(node2)) == 5): # 7 or 5 is cost for diagonals
			return 14 # for diagonal movement
			
	def process(self, screen): # implement the algorithm		
		self.current = self.start # make current node the starting node
		self.open.append(self.current) # add starting node to open list
		var = self.get_adjacent_nodes(self.current) # get all adjacent nodes for current node, set to var
		for i in var: # for every node in var list of nodes
			if i.reachable == True: # if they are reachable
				self.update_node(i, self.current) # calculates FGH, sets parent
				self.open.append(i) # add each node to open list
			
		self.open.remove(self.current) # remove current node from open list
		self.close.append(self.current) # add current node to closed list
		
		while len(self.open) != 0: # while open list is not empty

			self.open.sort(key = lambda x: x.f) # sort by lowest f
			self.current = self.open[0] # current is at index 0 of open list
			self.open.remove(self.current) # remove current node from open list
			self.close.append(self.current) # add current node to closed list
			
			adj_nodes = self.get_adjacent_nodes(self.current) # get the adjacent nodes for current node
			for adj_node in adj_nodes: # for every adjacent node in the list
				if adj_node.reachable and adj_node not in self.close: # if adj node is reachable and not in closed list
					if adj_node not in self.open: # and adjacent node is also not in open list
						self.update_node(adj_node, self.current) # calculates FGH, sets parent
						self.open.append(adj_node) # add node to open list
					else: # otherwise
						move = self.current.g + self.calc_g(self.current, adj_node) # uses G to measure move cost
						if move < adj_node.g: # if move cose is less than G cost
							self.current.parent = adj_node.parent # current parent equals adjacent node parent, setting path
							adj_node.g = calc_g(self.current, adj_node) # this node's G gets recalculated
										
			if self.goal in self.open: # if the goal is found in open list print & draw the path and end
				self.print_path() # print the path to console
				self.draw_path(screen) # draw the path on screen
				return True # goal was found
		return False # goal wasn't found