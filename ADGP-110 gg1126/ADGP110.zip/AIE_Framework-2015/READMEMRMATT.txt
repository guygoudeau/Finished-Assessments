To test the math library, press the 'p' key.
To check delta time, press the 'm' key.
My website is located at - http://guygoudeau.github.io/Poppit-and-Locket/