https://docs.google.com/document/d/1DClvwSi_nZHDf_SaJr3gVoSM4n-Mj7CZiAHeUdhFffU/edit?usp=sharing
