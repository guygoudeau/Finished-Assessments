﻿using UnityEngine;
using System.Collections;

public class InfoHandler : MonoBehaviour {

     public bool[] req = { false, false, false };
    [HideInInspector] public Time maxTime;
    [HideInInspector] public Time currentTime;

    void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
    }
}